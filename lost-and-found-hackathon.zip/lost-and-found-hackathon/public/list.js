// list.js - shows the items, filters, search and card buttons (Person 4)

// make text safe to put inside innerHTML (stops <script> tricks)
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// fetch items using the current filters and show them as cards
async function loadItems() {
  const params = new URLSearchParams();
  const type = document.getElementById("filter-type").value;
  const location = document.getElementById("filter-location").value;
  const q = document.getElementById("search").value.trim();
  const showResolved = document.getElementById("show-resolved").checked;

  if (type) params.set("type", type);
  if (location) params.set("location", location);
  if (q) params.set("q", q);
  if (showResolved) params.set("showResolved", "true");

  const res = await fetch("/api/items?" + params.toString());
  const items = await res.json();
  const box = document.getElementById("items");

  document.getElementById("count").textContent = items.length + (items.length === 1 ? " item" : " items");

  if (items.length === 0) {
    box.innerHTML = '<p class="empty">No items found.</p>';
    return;
  }

  let html = "";
  for (const it of items) {
    html += `
      <div class="card ${it.resolved ? "resolved" : ""}">
        <span class="badge ${it.type}">${it.type.toUpperCase()}</span>
        <h3>${escapeHtml(it.item)}</h3>
        <p>📍 ${escapeHtml(it.location)}</p>
        <p>📅 ${escapeHtml(it.date)}</p>
        <p>☎ ${escapeHtml(it.contact)}</p>
        <div class="card-buttons">
          <button class="matches-btn" data-id="${it._id}">Possible matches</button>
          ${it.resolved
            ? '<span class="done">Resolved ✓</span>'
            : `<button class="resolve-btn" data-id="${it._id}">Mark resolved</button>`}
        </div>
      </div>`;
  }
  box.innerHTML = html;
}

// one click listener for all card buttons (works for new cards too)
document.getElementById("items").addEventListener("click", async (event) => {
  const id = event.target.dataset.id;

  if (event.target.classList.contains("resolve-btn")) {
    if (!confirm("Mark this item as resolved?")) return;
    const res = await fetch("/api/items/" + id + "/resolve", { method: "PATCH" });
    if (res.ok) {
      loadItems();
    } else {
      const result = await res.json();
      alert(result.error);
    }
  }

  if (event.target.classList.contains("matches-btn")) {
    showMatches(id); // from matches.js
  }
});

// reload when a filter changes
document.getElementById("filter-type").addEventListener("change", loadItems);
document.getElementById("filter-location").addEventListener("change", loadItems);
document.getElementById("show-resolved").addEventListener("change", loadItems);

// wait 300 ms after typing stops before searching
let searchTimer;
document.getElementById("search").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadItems, 300);
});

loadItems();
