// matches.js - shows the "Possible matches" popup (Person 2)

async function showMatches(id) {
  const box = document.getElementById("matches-box");
  const res = await fetch("/api/items/" + id + "/matches");
  const matches = await res.json();

  if (!res.ok) {
    alert(matches.error);
    return;
  }

  let html = "<h3>Possible matches</h3>";
  if (matches.length === 0) {
    html += "<p>No matches yet. Check again later.</p>";
  } else {
    for (const m of matches) {
      html += `
        <div class="match">
          <span class="badge ${m.type}">${m.type.toUpperCase()}</span>
          <b>${escapeHtml(m.item)}</b>
          <p>📍 ${escapeHtml(m.location)} · 📅 ${escapeHtml(m.date)} · ☎ ${escapeHtml(m.contact)}</p>
        </div>`;
    }
  }
  html += '<button id="close-matches">Close</button>';

  box.innerHTML = html;
  box.hidden = false;
  document.getElementById("close-matches").onclick = () => (box.hidden = true);
}
