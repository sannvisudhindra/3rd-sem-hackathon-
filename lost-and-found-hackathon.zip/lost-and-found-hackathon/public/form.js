// form.js - sends the "Post an item" form to the server (Person 3)

const form = document.getElementById("post-form");
const message = document.getElementById("form-message");
const postButton = document.getElementById("post-button");

// today's date as YYYY-MM-DD
function today() {
  return new Date().toISOString().slice(0, 10);
}

form.date.value = today();
form.date.max = today(); // can't pick a future date

form.addEventListener("submit", async (event) => {
  event.preventDefault(); // stop the page from reloading

  const data = {
    type: form.type.value,
    item: form.item.value,
    location: form.location.value,
    date: form.date.value,
    contact: form.contact.value,
  };

  postButton.disabled = true;
  postButton.textContent = "Posting...";

  try {
    const res = await fetch("/api/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await res.json();

    if (res.ok) {
      message.textContent = "Posted!";
      message.className = "success";
      form.reset();
      form.date.value = today();
      loadItems(); // from list.js
    } else {
      message.textContent = result.error;
      message.className = "error";
    }
  } catch (err) {
    message.textContent = "Could not reach the server";
    message.className = "error";
  }

  postButton.disabled = false;
  postButton.textContent = "Post";
  setTimeout(() => (message.textContent = ""), 3000);
});
