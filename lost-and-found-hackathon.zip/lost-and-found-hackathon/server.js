// server.js - starts the Express app
const express = require("express");
const { connect } = require("./db");

const app = express();

app.use(express.json()); // read JSON bodies into req.body
app.use(express.static("public")); // serve index.html, css and js files

app.use("/api", require("./routes/items")); // Person 1: GET + POST /api/items
app.use("/api", require("./routes/extra")); // Person 2: resolve + matches

// start listening only after the database is connected
connect()
  .then(() => {
    app.listen(3000, () => console.log("Open http://127.0.0.1:3000/"));
  })
  .catch((err) => {
    console.error("Could not connect to MongoDB:", err.message);
    process.exit(1);
  });
