// db.js - connects to MongoDB once and shares the "items" collection
const { MongoClient } = require("mongodb");

const client = new MongoClient("mongodb://127.0.0.1:27017");
const DB_NAME = "Hack_MONGOse";

let db;

async function connect() {
  await client.connect();
  db = client.db(DB_NAME);
  console.log("Connected to MongoDB, database:", DB_NAME);
}

function items() {
  return db.collection("items");
}

module.exports = { connect, items, client, DB_NAME };
