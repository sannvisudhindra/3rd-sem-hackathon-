// seed.js - fills the items collection with sample data (Person 2)
// Run with: node seed.js
const { client, DB_NAME } = require("./db");

const sampleItems = [
  { type: "lost", item: "Black HP laptop charger", location: "Library", date: "2026-10-24", contact: "9876543210", resolved: false },
  { type: "found", item: "HP charger", location: "Library", date: "2026-10-25", contact: "priya@college.edu", resolved: false },
  { type: "lost", item: "Blue water bottle", location: "Canteen", date: "2026-10-23", contact: "9123456780", resolved: false },
  { type: "found", item: "Blue bottle", location: "Canteen", date: "2026-10-24", contact: "9988776655", resolved: false },
  { type: "lost", item: "College ID card", location: "Main Block", date: "2026-10-25", contact: "9000011111", resolved: false },
  { type: "found", item: "ID card", location: "Main Block", date: "2026-10-26", contact: "9000022222", resolved: false },
  { type: "lost", item: "Casio calculator", location: "Lab Block", date: "2026-10-22", contact: "9876500000", resolved: false },
  { type: "found", item: "Umbrella", location: "Parking", date: "2026-10-21", contact: "9555512345", resolved: false },
  { type: "lost", item: "Grey hoodie", location: "Hostel", date: "2026-10-19", contact: "9334455667", resolved: true },
  { type: "found", item: "Spectacles", location: "Sports Ground", date: "2026-10-20", contact: "9223344556", resolved: true },
];

async function seed() {
  await client.connect();
  const items = client.db(DB_NAME).collection("items");

  await items.deleteMany({}); // empty only our collection, never drop the database
  const docs = sampleItems.map((it) => ({ ...it, createdAt: new Date() }));
  const result = await items.insertMany(docs);

  console.log("Inserted", result.insertedCount, "items into", DB_NAME);
  await client.close();
}

seed().catch((err) => {
  console.error("Seed failed:", err.message);
  process.exit(1);
});
