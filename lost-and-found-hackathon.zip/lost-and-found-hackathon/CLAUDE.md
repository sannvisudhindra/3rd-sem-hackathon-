# Rules for the AI agent (Claude Code)

Project: **Campus Lost and Found Portal** (Hackathon problem 11). Keep it **simple** — beginners must be able to explain every line.
Read `docs/01-PLAN-AND-API.md` before writing code. Do not change route names or field names.

## Rules
- Node.js + Express + MongoDB with the official **`mongodb` driver**. Never Mongoose.
- **No new npm packages.** Only `express` and `mongodb`.
- MongoDB address: `mongodb://127.0.0.1:27017` (not `localhost`). Database: `Hack_MONGOse`. Collection: `items`.
- Run with `node server.js` on `http://127.0.0.1:3000/`.
- Convert ids with `new ObjectId(id)`; check `ObjectId.isValid(id)` first → 400.
- Errors are JSON: `{ "error": "message" }`. Status codes: 200, 201, 400, 404, 409.
- Frontend: plain HTML/CSS/JS in `public/`, use `fetch`. Use `escapeHtml()` for user text inside `innerHTML`.
- Small, simple code. No classes, no clever tricks. Explain each change in plain words.

## Who owns which file (only edit the files of the person you are helping)
| Person | Files |
| --- | --- |
| 1 · Server | `server.js`, `db.js`, `routes/items.js` |
| 2 · Resolve + Matches | `routes/extra.js`, `public/matches.js`, `seed.js` |
| 3 · Form + Design | `public/form.js`, `public/style.css`, the FORM part of `public/index.html` |
| 4 · List + Filters | `public/list.js`, the LIST part of `public/index.html` |
