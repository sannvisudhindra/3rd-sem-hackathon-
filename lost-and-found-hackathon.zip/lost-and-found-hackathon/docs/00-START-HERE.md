# 00 · Start Here (read together, 5 minutes)

## What we are building
A simple **Lost and Found** website for the campus:
1. Post an item as **lost** or **found** (item, location, date, contact).
2. See all posts. **Search** by name, **filter** by type and location.
3. Click **Mark resolved** when the item is returned. Resolved posts are hidden, with a **Show resolved** checkbox.
4. *Stretch:* **Possible matches** button → shows posts of the opposite type, same location, similar name.

That's it. Small and finished beats big and broken.

## Who does what (4 people)

| Person | Job | Files | Read |
| --- | --- | --- | --- |
| **1 · Server** | Database connection, add item, list/search items | `server.js`, `db.js`, `routes/items.js` | `PERSON-1-SERVER.md` |
| **2 · Resolve + Matches** | Mark resolved route, matches route + popup, sample data | `routes/extra.js`, `public/matches.js`, `seed.js` | `PERSON-2-RESOLVE-MATCHES.md` |
| **3 · Form + Design** | The "Post an item" form and the whole page's CSS | `public/form.js`, `public/style.css` | `PERSON-3-FORM-DESIGN.md` |
| **4 · List + Filters** | Showing the items, filters, search, resolve button | `public/list.js` | `PERSON-4-LIST-FILTERS.md` |

**Everyone** reads `01-PLAN-AND-API.md` (the agreement) and uses `02-TESTING-AND-DEMO.md` at the end.

**Golden rule:** only edit your own files. Then 4 people can code at the same time without breaking each other's work.

## Timeline (3 hours)

| Time | What |
| --- | --- |
| 0:00 – 0:20 | **Setup together** (below) |
| 0:20 – 1:20 | Everyone builds their part (steps 1–3 in your file) |
| **1:20** | **Merge #1** — put everything together, test it on one laptop |
| 1:20 – 2:20 | Everyone builds the rest of their part |
| **2:20** | **Merge #2** — full test with `02-TESTING-AND-DEMO.md` |
| 2:20 – 2:45 | Fix bugs, write README (Person 1) |
| 2:45 – 3:00 | Stop coding. Practise the demo. Explain each other's code. |

## Setup (20 minutes)

### Step 1 — Check every laptop
```bash
node -v      # 18 or higher
mongosh "mongodb://127.0.0.1:27017" --eval "db.runCommand({ping:1})"     # should say ok: 1
```

### About the code in this pack
This zip is a **complete, working app**. Every person's guide (`PERSON-x-....md`) has the full code for that person's
files at the bottom, and the same files are in the zip.

**Do not drop the whole finished app in with one commit.** Judges look at your commits and ask each of you about your
own code. Instead, start from an empty skeleton (Step 2), and each person adds their own files step by step, committing
as they go. Use the finished code as your answer key.

### Step 2 — Person 1 creates the project (the skeleton)
```bash
cp -r 05-student-management-app/snapshot ~/Desktop/Hack_MONGOse      # or copy the folder in Explorer/Finder
cd ~/Desktop/Hack_MONGOse
```
Delete the snapshot's old code (old `server.js`, old routes, old `public/` files). Then copy these files **from the zip** in:
- `CLAUDE.md`, `README.md`, `.gitignore`, `package.json`
- the whole `docs/` folder

Then run `npm install`.

### Step 3 — Person 4 adds the HTML page
Copy `public/index.html` from the zip (it is also in `PERSON-4-LIST-FILTERS.md`).
Create empty files: `public/list.js`, `public/form.js`, `public/matches.js`, `public/style.css`.

### Want to just see it working first? (5 minutes, any one laptop)
Unzip somewhere else, then run `npm install`, `node seed.js` and `node server.js`, and open `http://127.0.0.1:3000/`.
Now everyone knows what you're building. Close it and go back to your team folder.

### Step 4 — Put it on GitHub (Person 1)
```bash
git init
git add .
git commit -m "Starter project and plan"
git branch -M main
git remote add origin https://github.com/<username>/hack-lost-and-found.git   # make an empty repo on github.com first
git push -u origin main
```
Add the other 3 as collaborators (GitHub → Settings → Collaborators).

### Step 5 — Everyone else
```bash
git clone https://github.com/<username>/hack-lost-and-found.git
cd hack-lost-and-found
npm install
git checkout -b person2        # use your own number: person1 / person2 / person3 / person4
```

### Step 6 — First message to the agent (everyone)
> Read CLAUDE.md and docs/01-PLAN-AND-API.md and the existing code. Explain in 5 short bullet points how this
> project is set up. Do not write any code yet.

## Saving your work (Git)
After **every** step that works:
```bash
git add .
git commit -m "Add search filter"        # say what you added
git push -u origin person2               # your branch
```
Agent made a mess? `git restore .` throws away changes since your last commit.

## Merging (at 1:20 and 2:20 — Person 1 does it, others watch)
Everyone pushes first. Then Person 1:
```bash
git checkout main
git pull origin main
git merge origin/person1 -m "Merge person 1"
git merge origin/person2 -m "Merge person 2"
git merge origin/person3 -m "Merge person 3"
git merge origin/person4 -m "Merge person 4"
git push origin main
```
Then everyone: `git pull origin main` (while on your own branch) to get everyone's work.

No internet / GitHub? Copy your files to Person 1's laptop with a USB stick or a shared folder at the merge times.

## Done means
- [ ] `node server.js` → page opens at `http://127.0.0.1:3000/`
- [ ] Data stays after restarting the server
- [ ] Wrong input → JSON error with 400 / 404 / 409
- [ ] All 4 Must features work
- [ ] At least 5 commits (we'll have way more)
- [ ] README.md with what it does, how to run, the routes
