# 02 · Testing and Demo (everyone, after Merge #2)

Run on one laptop: `node seed.js` then `node server.js`. Tick each box.

## API tests (Person 2 runs these in Postman or the terminal)
| # | Test | Expected | ✓ |
| --- | --- | --- | --- |
| 1 | GET `/api/items` | 200, 8 items, no resolved ones | |
| 2 | GET `/api/items?showResolved=true` | 10 items | |
| 3 | GET `/api/items?type=found&location=Library` | only "HP charger" | |
| 4 | GET `/api/items?q=CHARGER` | both chargers | |
| 5 | POST a good item | **201** | |
| 6 | POST with `"type":"stolen"` | **400** + error message | |
| 7 | POST with `item` missing | **400** | |
| 8 | PATCH `/api/items/<id>/resolve` | **200** | |
| 9 | Same PATCH again | **409** | |
| 10 | PATCH `/api/items/abc/resolve` | **400** | |
| 11 | PATCH `/api/items/000000000000000000000000/resolve` | **404** | |
| 12 | GET `/api/items/<charger id>/matches` | contains "HP charger" | |
| 13 | Every error looks like `{ "error": "..." }` | | |

## Page tests (Persons 3 and 4)
| # | Test | ✓ |
| --- | --- | --- |
| 14 | Page loads, no red errors in F12 Console | |
| 15 | Post an item → appears in the list without refreshing | |
| 16 | Type, location, search and Show resolved all work, also together | |
| 17 | Mark resolved → card disappears; Show resolved → back, grey | |
| 18 | Possible matches → popup shows; Close works | |
| 19 | Post an item called `<b>hello</b>` → shows as text, not bold | |
| 20 | Narrow window (phone size) still looks OK | |

## Restart test (Person 1)
| # | Test | ✓ |
| --- | --- | --- |
| 21 | Post an item, stop the server (Ctrl+C), start it again, refresh → item still there | |

## Before the judges
- [ ] `git log --oneline` shows at least 5 commits
- [ ] README is up to date
- [ ] Run `node seed.js` right before the demo for clean data

---

## Demo (about 3 minutes, each person speaks)

| Who | Shows | Says |
| --- | --- | --- |
| Person 1 | The page | "Campus Lost & Found: post lost or found items, search them, mark them resolved, and get match suggestions. Node, Express, MongoDB, plain JavaScript." |
| Person 3 | Post a **found** "Black charger" at Library | "The form sends JSON to our POST route. The server checks every field. If I send bad data, I get a 400." |
| Person 4 | Filters: Lost/Found, Library, search "charger", Show resolved | "The filters go into the URL and MongoDB does the search on the server." |
| Person 2 | "Possible matches" on the charger, then **Mark resolved** | "Matches: opposite type, same location, a shared word. Resolving sets `resolved: true`; doing it twice gives 409." |
| Person 1 | Stop and restart the server, refresh | "The data is saved in MongoDB, so it survives a restart." |

## Practise: explain each other's code (last 10 minutes)
Judges can point at **any** line and ask anyone. So:
1. Each person explains one other person's file to the team.
2. Anything nobody can explain → ask the agent: *"Explain lines X to Y of this file simply, in 5 sentences."*
