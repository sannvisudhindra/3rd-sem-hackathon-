# Person 4 · Item list, filters, card buttons

**Your files:** `public/list.js`, and `public/index.html` (you paste the whole page at setup; after that, only edit between `LIST START` and `LIST END`)
**Your branch:** `person4`

The complete, tested code for your files is at the bottom of this page. You can use it in two ways:
- **Build it (better for judging):** follow the steps, give each prompt to the agent, and compare what it writes with the final code.
- **Short on time:** copy in the final code one file at a time, then ask the agent *"Explain this file line by line, simply"* until you can explain it yourself.

**At setup:** paste the full `index.html` (below) into `public/index.html`. Create empty `list.js`, `form.js`, `matches.js` and `style.css`, then commit and push to `main` before anyone branches.

---

## Step 1 · Show items as cards (25 min)
**Prompt:**
> Read CLAUDE.md and docs/01-PLAN-AND-API.md. In public/list.js write escapeHtml(text) and loadItems().
> loadItems fetches /api/items and shows each item as a card in #items: a LOST/FOUND badge, the item name, location,
> date and contact, a "Possible matches" button and a "Mark resolved" button (if resolved, show "Resolved ✓"
> instead). Put the item _id in data-id. Show "No items found." when the list is empty, and the count in #count.
> Call loadItems() when the page loads.

**Test:** open `http://127.0.0.1:3000/` and the cards show (run `node seed.js` once Person 2 pushes it).
**Commit + push.** Person 3 needs `loadItems`.

## Step 2 · Filters, search, show resolved (25 min)
**Prompt:**
> Make loadItems() read #filter-type, #filter-location, #search and #show-resolved, and build the URL with
> URLSearchParams. Only add the filters that have a value, and add showResolved=true only when the box is ticked.
> Reload when a filter changes. For the search box, wait 300 ms after typing stops.

**Test:** try each filter alone, then two together, then search "charger", then tick Show resolved. Watch F12 → Network to see the URL change.
**Commit.**

🟢 **Merge #1 at 1:20.**

## Step 3 · Card buttons (20 min)
This needs Person 2's resolve route and `showMatches()` to be merged in first.
**Prompt:**
> Add one click listener on #items. If a .resolve-btn was clicked: confirm(), then PATCH /api/items/<data-id>/resolve.
> If OK call loadItems(), else alert the server's error. If a .matches-btn was clicked: call showMatches(<data-id>).

**Test:** click **Mark resolved** and the card disappears. Tick **Show resolved** and it comes back grey with "Resolved ✓". Click **Possible matches** and the popup opens.
**Commit.**

---

## Questions judges may ask you
| Question | Answer |
| --- | --- |
| What does `escapeHtml` do? | If someone posts `<script>`, it shows as text instead of running as code. |
| Where does filtering happen? | On the server. The page only puts the filters into the URL; MongoDB does the search. |
| What is `URLSearchParams`? | It safely builds the `?type=lost&q=pen` part of the URL. |
| Why one click listener on `#items`? | The cards are rebuilt on every load. One listener on the parent works for every button, even new ones (this is called event delegation). |
| What is `data-id`? | Each button stores its item's `_id`, so we know which item was clicked. |
| Why wait 300 ms on search? | So we don't call the server on every single key press. |

---

## Full code

### `public/index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Campus Lost &amp; Found</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Campus Lost &amp; Found</h1>
    <p>Lost something? Found something? Post it here.</p>
  </header>

  <main>
    <!-- FORM START (Person 3) -->
    <section id="post-section">
      <h2>Post an item</h2>
      <form id="post-form">
        <label>Type
          <select name="type" required>
            <option value="lost">Lost</option>
            <option value="found">Found</option>
          </select>
        </label>
        <label>Item
          <input name="item" placeholder="e.g. Black laptop charger" required>
        </label>
        <label>Location
          <select name="location" required>
            <option>Library</option><option>Canteen</option><option>Main Block</option><option>Lab Block</option>
            <option>Hostel</option><option>Parking</option><option>Sports Ground</option><option>Other</option>
          </select>
        </label>
        <label>Date
          <input type="date" name="date" required>
        </label>
        <label>Contact
          <input name="contact" placeholder="Phone or email" required>
        </label>
        <button type="submit" id="post-button">Post</button>
      </form>
      <p id="form-message"></p>
    </section>
    <!-- FORM END -->

    <!-- LIST START (Person 4) -->
    <section id="list-section">
      <div id="filters">
        <select id="filter-type">
          <option value="">All</option>
          <option value="lost">Lost</option>
          <option value="found">Found</option>
        </select>
        <select id="filter-location">
          <option value="">All locations</option>
          <option>Library</option><option>Canteen</option><option>Main Block</option><option>Lab Block</option>
          <option>Hostel</option><option>Parking</option><option>Sports Ground</option><option>Other</option>
        </select>
        <input id="search" placeholder="Search items...">
        <label class="switch"><input type="checkbox" id="show-resolved"> Show resolved</label>
      </div>
      <p id="count"></p>
      <div id="items"></div>
    </section>
    <!-- LIST END -->
  </main>

  <!-- Person 2 fills this from matches.js -->
  <div id="matches-box" hidden></div>

  <script src="list.js"></script>
  <script src="matches.js"></script>
  <script src="form.js"></script>
</body>
</html>
```

### `public/list.js`
```js
// list.js - shows the items, filters, search and card buttons (Person 4)

// make text safe to put inside innerHTML (stops <script> tricks)
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// fetch items using the current filters and show them as cards
async function loadItems() {
  const params = new URLSearchParams();
  const type = document.getElementById("filter-type").value;
  const location = document.getElementById("filter-location").value;
  const q = document.getElementById("search").value.trim();
  const showResolved = document.getElementById("show-resolved").checked;

  if (type) params.set("type", type);
  if (location) params.set("location", location);
  if (q) params.set("q", q);
  if (showResolved) params.set("showResolved", "true");

  const res = await fetch("/api/items?" + params.toString());
  const items = await res.json();
  const box = document.getElementById("items");

  document.getElementById("count").textContent = items.length + (items.length === 1 ? " item" : " items");

  if (items.length === 0) {
    box.innerHTML = '<p class="empty">No items found.</p>';
    return;
  }

  let html = "";
  for (const it of items) {
    html += `
      <div class="card ${it.resolved ? "resolved" : ""}">
        <span class="badge ${it.type}">${it.type.toUpperCase()}</span>
        <h3>${escapeHtml(it.item)}</h3>
        <p>📍 ${escapeHtml(it.location)}</p>
        <p>📅 ${escapeHtml(it.date)}</p>
        <p>☎ ${escapeHtml(it.contact)}</p>
        <div class="card-buttons">
          <button class="matches-btn" data-id="${it._id}">Possible matches</button>
          ${it.resolved
            ? '<span class="done">Resolved ✓</span>'
            : `<button class="resolve-btn" data-id="${it._id}">Mark resolved</button>`}
        </div>
      </div>`;
  }
  box.innerHTML = html;
}

// one click listener for all card buttons (works for new cards too)
document.getElementById("items").addEventListener("click", async (event) => {
  const id = event.target.dataset.id;

  if (event.target.classList.contains("resolve-btn")) {
    if (!confirm("Mark this item as resolved?")) return;
    const res = await fetch("/api/items/" + id + "/resolve", { method: "PATCH" });
    if (res.ok) {
      loadItems();
    } else {
      const result = await res.json();
      alert(result.error);
    }
  }

  if (event.target.classList.contains("matches-btn")) {
    showMatches(id); // from matches.js
  }
});

// reload when a filter changes
document.getElementById("filter-type").addEventListener("change", loadItems);
document.getElementById("filter-location").addEventListener("change", loadItems);
document.getElementById("show-resolved").addEventListener("change", loadItems);

// wait 300 ms after typing stops before searching
let searchTimer;
document.getElementById("search").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadItems, 300);
});

loadItems();
```
