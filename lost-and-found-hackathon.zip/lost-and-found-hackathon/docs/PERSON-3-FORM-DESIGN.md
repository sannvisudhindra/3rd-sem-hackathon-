# Person 3 · Post form and page design

**Your files:** `public/form.js`, `public/style.css`, and the part of `public/index.html` between `FORM START` and `FORM END`
**Your branch:** `person3`
Design and usability is worth **15 points**, and most of that is your work.

The complete, tested code for your files is at the bottom of this page. You can use it in two ways:
- **Build it (better for judging):** follow the steps, give each prompt to the agent, and compare what it writes with the final code.
- **Short on time:** copy in the final code one file at a time, then ask the agent *"Explain this file line by line, simply"* until you can explain it yourself.

You can style the page right away. The form can only save once Person 1 pushes POST `/api/items`; run `git pull origin person1` then.

---

## Step 1 · Send the form (25 min)
**Prompt:**
> Read CLAUDE.md and docs/01-PLAN-AND-API.md. In public/form.js, when #post-form is submitted: prevent the page reload,
> read type, item, location, date and contact, and POST them as JSON to /api/items. While it is sending, disable the
> button and show "Posting...". If OK: show "Posted!" in #form-message (class success), reset the form, and call
> loadItems(). If not OK: show the server's error (class error). Default the date to today and set max to today.
> Clear the message after 3 seconds.

**Test:**
- Post an item. "Posted!" appears, and the item shows up in the list.
- In F12 → Elements, delete `required` from the Item input and submit it empty. The server's red error message shows, which proves the server checks too.

**Commit:** `git add . && git commit -m "Send post form to the API" && git push -u origin person3`

## Step 2 · Style the page (40 min)
**Prompt:**
> Write public/style.css for index.html. Clean, modern and phone-friendly, with CSS variables for colours and the system font.
> On wide screens put the form on the left (320px) and the list on the right; on screens under 800px use one column.
> Inputs are full width. The Post button is big. .success is green and .error is red. The filters sit in a wrapping row.
> Cards (.card) go in a grid. .badge.lost is red and .badge.found is green. .card.resolved is grey and faded.
> #matches-box is a centred popup with a dark backdrop. No libraries.

The card HTML that Person 4 builds (agree class names with them):
```html
<div class="card resolved">
  <span class="badge lost">LOST</span>
  <h3>Black charger</h3>
  <p>📍 Library</p><p>📅 2026-10-25</p><p>☎ 9876543210</p>
  <div class="card-buttons">
    <button class="matches-btn">Possible matches</button>
    <button class="resolve-btn">Mark resolved</button>
  </div>
</div>
```
**Checklist:** looks good both wide and narrow, LOST and FOUND are obvious, buttons change on hover, and the popup is centred.
**Commit:** `git commit -am "Style the page"`

🟢 **Merge #1 at 1:20.** Check the real cards with Person 4 and fix anything that looks off.

---

## Questions judges may ask you
| Question | Answer |
| --- | --- |
| What does `event.preventDefault()` do? | It stops the browser reloading the page when the form is submitted. |
| What does `JSON.stringify` do? | It turns the JavaScript object into JSON text to send to the server. |
| What is `res.ok`? | It is true when the status is 200–299. Otherwise we show the server's error message. |
| If I skip the form and send bad data with Postman? | The server still checks it and returns 400. The form's checks are only for convenience. |
| How does the list update after posting? | form.js calls `loadItems()`, which comes from list.js. |
| Why disable the button while posting? | So a double click doesn't post the item twice. |
| How does the layout change on phones? | The `@media (max-width: 800px)` rule switches the grid to one column. |

---

## Full code

### `public/form.js`
```js
// form.js - sends the "Post an item" form to the server (Person 3)

const form = document.getElementById("post-form");
const message = document.getElementById("form-message");
const postButton = document.getElementById("post-button");

// today's date as YYYY-MM-DD
function today() {
  return new Date().toISOString().slice(0, 10);
}

form.date.value = today();
form.date.max = today(); // can't pick a future date

form.addEventListener("submit", async (event) => {
  event.preventDefault(); // stop the page from reloading

  const data = {
    type: form.type.value,
    item: form.item.value,
    location: form.location.value,
    date: form.date.value,
    contact: form.contact.value,
  };

  postButton.disabled = true;
  postButton.textContent = "Posting...";

  try {
    const res = await fetch("/api/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await res.json();

    if (res.ok) {
      message.textContent = "Posted!";
      message.className = "success";
      form.reset();
      form.date.value = today();
      loadItems(); // from list.js
    } else {
      message.textContent = result.error;
      message.className = "error";
    }
  } catch (err) {
    message.textContent = "Could not reach the server";
    message.className = "error";
  }

  postButton.disabled = false;
  postButton.textContent = "Post";
  setTimeout(() => (message.textContent = ""), 3000);
});
```

### `public/style.css`
```css
/* style.css - the look of the whole page (Person 3) */
:root {
  --bg: #f4f6fb;
  --card: #ffffff;
  --text: #1f2937;
  --muted: #6b7280;
  --primary: #4f46e5;
  --primary-dark: #4338ca;
  --lost: #ef4444;
  --found: #16a34a;
  --border: #e5e7eb;
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  background: var(--bg);
  color: var(--text);
}

header {
  background: linear-gradient(135deg, var(--primary), #7c3aed);
  color: white;
  text-align: center;
  padding: 28px 16px;
}

header h1 {
  margin: 0 0 6px;
}

header p {
  margin: 0;
  opacity: 0.9;
}

main {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 24px;
  max-width: 1200px;
  margin: 24px auto;
  padding: 0 16px;
}

section {
  background: var(--card);
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

#post-section {
  align-self: start;
}

h2 {
  margin-top: 0;
}

/* form */
#post-form label {
  display: block;
  font-weight: 600;
  font-size: 14px;
  margin-bottom: 12px;
}

input,
select {
  width: 100%;
  padding: 10px;
  margin-top: 4px;
  border: 1px solid var(--border);
  border-radius: 8px;
  font-size: 15px;
  font-family: inherit;
  background: white;
  color: var(--text);
}

input:focus,
select:focus {
  outline: 2px solid var(--primary);
  border-color: transparent;
}

button {
  cursor: pointer;
  border: none;
  border-radius: 8px;
  padding: 8px 12px;
  font-size: 14px;
  font-family: inherit;
}

#post-button {
  width: 100%;
  padding: 12px;
  font-size: 16px;
  font-weight: 600;
  background: var(--primary);
  color: white;
}

#post-button:hover {
  background: var(--primary-dark);
}

#post-button:disabled {
  opacity: 0.6;
  cursor: wait;
}

#form-message {
  min-height: 20px;
  font-weight: 600;
}

.success {
  color: var(--found);
}

.error {
  color: var(--lost);
}

/* filters */
#filters {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
}

#filters select,
#filters input {
  width: auto;
  flex: 1 1 150px;
  margin-top: 0;
}

#filters .switch {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  white-space: nowrap;
}

#filters .switch input {
  width: auto;
  flex: none;
}

#count {
  color: var(--muted);
  font-size: 14px;
}

/* item cards */
#items {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.card {
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 16px;
  background: var(--card);
  transition: transform 0.15s, box-shadow 0.15s;
}

.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
}

.card h3 {
  margin: 10px 0 8px;
}

.card p {
  margin: 4px 0;
  color: var(--muted);
  font-size: 14px;
}

.card.resolved {
  opacity: 0.55;
  background: #f3f4f6;
}

.badge {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  color: white;
}

.badge.lost {
  background: var(--lost);
}

.badge.found {
  background: var(--found);
}

.card-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 12px;
}

.matches-btn {
  background: #eef2ff;
  color: var(--primary);
}

.matches-btn:hover {
  background: #e0e7ff;
}

.resolve-btn {
  background: var(--found);
  color: white;
}

.resolve-btn:hover {
  background: #15803d;
}

.done {
  color: var(--found);
  font-weight: 700;
  align-self: center;
}

.empty {
  color: var(--muted);
  grid-column: 1 / -1;
  text-align: center;
  padding: 30px;
}

/* matches popup */
#matches-box {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: min(90vw, 440px);
  max-height: 80vh;
  overflow-y: auto;
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 0 0 100vmax rgba(0, 0, 0, 0.4); /* dark backdrop */
  z-index: 10;
}

#matches-box[hidden] {
  display: none;
}

#matches-box h3 {
  margin-top: 0;
}

.match {
  border-bottom: 1px solid var(--border);
  padding: 10px 0;
}

.match p {
  margin: 4px 0 0;
  color: var(--muted);
  font-size: 14px;
}

#close-matches {
  margin-top: 12px;
  background: var(--primary);
  color: white;
}

/* phones */
@media (max-width: 800px) {
  main {
    grid-template-columns: 1fr;
  }
}
```
