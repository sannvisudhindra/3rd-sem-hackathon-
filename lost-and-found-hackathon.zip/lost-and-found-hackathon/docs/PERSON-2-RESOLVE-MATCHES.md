# Person 2 · Resolve, Matches, Sample data

**Your files:** `routes/extra.js`, `public/matches.js`, `seed.js`
**Your branch:** `person2`
**Extra job:** at Merge #2 you run the API tests in `02-TESTING-AND-DEMO.md`.

The complete, tested code for your files is at the bottom of this page. You can use it in two ways:
- **Build it (better for judging):** follow the steps, give each prompt to the agent, and compare what it writes with the final code.
- **Short on time:** copy in the final code one file at a time, then ask the agent *"Explain this file line by line, simply"* until you can explain it yourself.

Your files need Person 1's `db.js`. Once Person 1 pushes step 1, run `git pull origin person1`.

---

## Step 1 · seed.js: sample data (15 min)
**Prompt:**
> Create seed.js. Use client and DB_NAME from db.js. Delete all documents in the "items" collection only (never drop
> the database), insert my 10 sample items with createdAt:new Date(), print how many were inserted, and close the
> connection.

The sample items are in the final code below: 3 matching pairs, plus 2 items that are already resolved.
**Test:** `node seed.js` prints `Inserted 10 items`. Then `http://127.0.0.1:3000/api/items` shows 8 items.
**Commit + push**, then tell everyone: *"run `node seed.js` for sample data"*.

## Step 2 · PATCH /api/items/:id/resolve (20 min)
**Prompt:**
> In routes/extra.js add PATCH /items/:id/resolve. If ObjectId.isValid fails, return 400 "Invalid id". If the item
> isn't found, 404 "Item not found". If it's already resolved, 409 "Item is already resolved". Otherwise $set
> resolved:true and return the item.

**Test** (copy a real `_id` from `/api/items`):
```bash
curl -i -X PATCH http://127.0.0.1:3000/api/items/<id>/resolve                         # 200
curl -i -X PATCH http://127.0.0.1:3000/api/items/<id>/resolve                         # 409
curl -i -X PATCH http://127.0.0.1:3000/api/items/abc/resolve                          # 400
curl -i -X PATCH http://127.0.0.1:3000/api/items/000000000000000000000000/resolve     # 404
```
**Commit + push**, then tell Person 4.

🟢 **Merge #1 at 1:20.**

## Step 3 · GET /api/items/:id/matches (20 min)
**Prompt:**
> Add GET /items/:id/matches. Return 400 or 404 the same way as the resolve route. Find items with the opposite type,
> the same location and resolved:false. Keep only those whose name shares a word of 3 or more letters with this
> item's name (lowercase). Return them.

**Test** (after `node seed.js`): the id of "Black HP laptop charger" returns "HP charger". The id of "Umbrella" returns `[]`.
**Commit.**

## Step 4 · public/matches.js: the popup (20 min)
**Prompt:**
> In public/matches.js write a global function showMatches(id). It fetches /api/items/<id>/matches and fills
> #matches-box with a "Possible matches" title and one row per match (badge, item, location, date, contact, using
> escapeHtml from list.js), or "No matches yet". Add a Close button that hides the box, then show the box.

**Test after Merge #1:** click **Possible matches** on the charger card. The popup shows HP charger, and **Close** works.
**Commit.**

🟢 **Merge #2 at 2:20.** Run the API tests in `02-TESTING-AND-DEMO.md`.

---

## Questions judges may ask you
| Question | Answer |
| --- | --- |
| What does `ObjectId` do? | MongoDB ids aren't plain text. `new ObjectId(id)` turns the text from the URL into a real id, so `findOne` can find the item. |
| Why `ObjectId.isValid` first? | `new ObjectId("abc")` would crash. Checking first lets us send a clean 400 instead. |
| Why 409 when it's already resolved? | The request is valid, but it conflicts with the data's current state. |
| What does `$set` do? | It changes only the `resolved` field and leaves the rest of the item as it was. |
| How do matches work? | Opposite type, same location, not resolved, and at least one word in common in the name. |
| Why is the word check done in JavaScript, not MongoDB? | MongoDB does the fast filtering (type, location). Comparing words is easier in JS, and by then only a few items are left. |
| Why `deleteMany({})` and not `dropDatabase()`? | It only empties our own collection, so we can't destroy anything else by accident. |

---

## Full code

### `routes/extra.js`
```js
// routes/extra.js - mark resolved + possible matches (Person 2)
const express = require("express");
const { ObjectId } = require("mongodb");
const { items } = require("../db");

const router = express.Router();

// PATCH /api/items/:id/resolve - mark an item as resolved
router.patch("/items/:id/resolve", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid id" });
    }

    const item = await items().findOne({ _id: new ObjectId(id) });
    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }
    if (item.resolved) {
      return res.status(409).json({ error: "Item is already resolved" });
    }

    await items().updateOne({ _id: new ObjectId(id) }, { $set: { resolved: true } });
    item.resolved = true;
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// split a name into lowercase words with 3 or more letters
function words(text) {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 3);
}

// GET /api/items/:id/matches - opposite type, same location, a word in common
router.get("/items/:id/matches", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid id" });
    }

    const item = await items().findOne({ _id: new ObjectId(id) });
    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }

    const otherType = item.type === "lost" ? "found" : "lost";
    const candidates = await items()
      .find({ type: otherType, location: item.location, resolved: false })
      .toArray();

    const myWords = words(item.item);
    const matches = candidates.filter((c) => words(c.item).some((w) => myWords.includes(w)));
    res.json(matches);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
```

### `public/matches.js`
```js
// matches.js - shows the "Possible matches" popup (Person 2)

async function showMatches(id) {
  const box = document.getElementById("matches-box");
  const res = await fetch("/api/items/" + id + "/matches");
  const matches = await res.json();

  if (!res.ok) {
    alert(matches.error);
    return;
  }

  let html = "<h3>Possible matches</h3>";
  if (matches.length === 0) {
    html += "<p>No matches yet. Check again later.</p>";
  } else {
    for (const m of matches) {
      html += `
        <div class="match">
          <span class="badge ${m.type}">${m.type.toUpperCase()}</span>
          <b>${escapeHtml(m.item)}</b>
          <p>📍 ${escapeHtml(m.location)} · 📅 ${escapeHtml(m.date)} · ☎ ${escapeHtml(m.contact)}</p>
        </div>`;
    }
  }
  html += '<button id="close-matches">Close</button>';

  box.innerHTML = html;
  box.hidden = false;
  document.getElementById("close-matches").onclick = () => (box.hidden = true);
}
```

### `seed.js`
```js
// seed.js - fills the items collection with sample data (Person 2)
// Run with: node seed.js
const { client, DB_NAME } = require("./db");

const sampleItems = [
  { type: "lost", item: "Black HP laptop charger", location: "Library", date: "2026-10-24", contact: "9876543210", resolved: false },
  { type: "found", item: "HP charger", location: "Library", date: "2026-10-25", contact: "priya@college.edu", resolved: false },
  { type: "lost", item: "Blue water bottle", location: "Canteen", date: "2026-10-23", contact: "9123456780", resolved: false },
  { type: "found", item: "Blue bottle", location: "Canteen", date: "2026-10-24", contact: "9988776655", resolved: false },
  { type: "lost", item: "College ID card", location: "Main Block", date: "2026-10-25", contact: "9000011111", resolved: false },
  { type: "found", item: "ID card", location: "Main Block", date: "2026-10-26", contact: "9000022222", resolved: false },
  { type: "lost", item: "Casio calculator", location: "Lab Block", date: "2026-10-22", contact: "9876500000", resolved: false },
  { type: "found", item: "Umbrella", location: "Parking", date: "2026-10-21", contact: "9555512345", resolved: false },
  { type: "lost", item: "Grey hoodie", location: "Hostel", date: "2026-10-19", contact: "9334455667", resolved: true },
  { type: "found", item: "Spectacles", location: "Sports Ground", date: "2026-10-20", contact: "9223344556", resolved: true },
];

async function seed() {
  await client.connect();
  const items = client.db(DB_NAME).collection("items");

  await items.deleteMany({}); // empty only our collection, never drop the database
  const docs = sampleItems.map((it) => ({ ...it, createdAt: new Date() }));
  const result = await items.insertMany(docs);

  console.log("Inserted", result.insertedCount, "items into", DB_NAME);
  await client.close();
}

seed().catch((err) => {
  console.error("Seed failed:", err.message);
  process.exit(1);
});
```
