# 01 · Plan and API (everyone follows this — don't change names)

## 1. The data — collection `items`

```json
{
  "_id": "6650f1c2a1b2c3d4e5f60718",
  "type": "lost",
  "item": "Black laptop charger",
  "location": "Library",
  "date": "2026-10-25",
  "contact": "9876543210",
  "resolved": false,
  "createdAt": "2026-10-27T09:15:00.000Z"
}
```

| Field | Rule (checked by the server) |
| --- | --- |
| `type` | must be `"lost"` or `"found"` |
| `item` | required, not empty |
| `location` | required, not empty |
| `date` | required, format `YYYY-MM-DD` (what `<input type="date">` gives), not in the future |
| `contact` | required, not empty |
| `resolved` | the server sets it to `false` when the item is posted |
| `createdAt` | the server sets it |

Locations (same list everywhere): **Library, Canteen, Main Block, Lab Block, Hostel, Parking, Sports Ground, Other**

## 2. The routes

| Method | Route | Who builds it | What it does | Status codes |
| --- | --- | --- | --- | --- |
| GET | `/api/items` | Person 1 | List items. Optional `?type=lost&location=Library&q=charger&showResolved=true` | 200 |
| POST | `/api/items` | Person 1 | Add an item | 201, 400 |
| PATCH | `/api/items/:id/resolve` | Person 2 | Mark an item resolved | 200, 400, 404, 409 |
| GET | `/api/items/:id/matches` | Person 2 | Possible matches (stretch) | 200, 400, 404 |

Details:
- **GET `/api/items`** — without `showResolved=true`, only items with `resolved: false`. `q` searches `item`, ignoring upper/lower case. Newest first.
- **POST `/api/items`** — returns `201` and the saved item. Missing field or bad type → `400 { "error": "..." }`.
- **PATCH `/api/items/:id/resolve`** — bad id → `400`, not found → `404`, already resolved → `409`, else `200` + the item.
- **GET `/api/items/:id/matches`** — items with the **opposite type**, **same location**, **not resolved**, whose name shares a word (3+ letters) with this item.

All errors look like: `{ "error": "Item not found" }`

## 3. How the frontend files work together

| File | Owner | Gives to others |
| --- | --- | --- |
| `list.js` | Person 4 | `loadItems()` — reloads the list. `escapeHtml(text)` — makes text safe for `innerHTML` |
| `matches.js` | Person 2 | `showMatches(id)` — shows the matches box for one item |
| `form.js` | Person 3 | — (calls `loadItems()` after posting) |

So:
- After posting, `form.js` calls `loadItems()` so the new item appears.
- The "Possible matches" button in `list.js` calls `showMatches(id)`.

## 4. The page — `public/index.html` (Person 4 pastes this at setup)

Person 3 may only change the part between `FORM START` and `FORM END`; Person 4 the part between `LIST START` and `LIST END`.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Campus Lost &amp; Found</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Campus Lost &amp; Found</h1>
    <p>Lost something? Found something? Post it here.</p>
  </header>

  <main>
    <!-- FORM START (Person 3) -->
    <section id="post-section">
      <h2>Post an item</h2>
      <form id="post-form">
        <label>Type
          <select name="type" required>
            <option value="lost">Lost</option>
            <option value="found">Found</option>
          </select>
        </label>
        <label>Item
          <input name="item" placeholder="e.g. Black laptop charger" required>
        </label>
        <label>Location
          <select name="location" required>
            <option>Library</option><option>Canteen</option><option>Main Block</option><option>Lab Block</option>
            <option>Hostel</option><option>Parking</option><option>Sports Ground</option><option>Other</option>
          </select>
        </label>
        <label>Date
          <input type="date" name="date" required>
        </label>
        <label>Contact
          <input name="contact" placeholder="Phone or email" required>
        </label>
        <button type="submit" id="post-button">Post</button>
      </form>
      <p id="form-message"></p>
    </section>
    <!-- FORM END -->

    <!-- LIST START (Person 4) -->
    <section id="list-section">
      <div id="filters">
        <select id="filter-type">
          <option value="">All</option>
          <option value="lost">Lost</option>
          <option value="found">Found</option>
        </select>
        <select id="filter-location">
          <option value="">All locations</option>
          <option>Library</option><option>Canteen</option><option>Main Block</option><option>Lab Block</option>
          <option>Hostel</option><option>Parking</option><option>Sports Ground</option><option>Other</option>
        </select>
        <input id="search" placeholder="Search items...">
        <label class="switch"><input type="checkbox" id="show-resolved"> Show resolved</label>
      </div>
      <p id="count"></p>
      <div id="items"></div>
    </section>
    <!-- LIST END -->
  </main>

  <!-- Person 2 fills this from matches.js -->
  <div id="matches-box" hidden></div>

  <script src="list.js"></script>
  <script src="matches.js"></script>
  <script src="form.js"></script>
</body>
</html>
```
