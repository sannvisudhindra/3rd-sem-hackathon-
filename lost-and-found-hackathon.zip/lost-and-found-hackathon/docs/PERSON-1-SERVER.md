# Person 1 · Server (database, add item, list items)

**Your files:** `package.json`, `server.js`, `db.js`, `routes/items.js`
**Your branch:** `person1`
**Extra jobs:** you merge everyone's work at 1:20 and 2:20, and you update `README.md` at the end.

The complete, tested code for your files is at the bottom of this page. You can use it in two ways:
- **Build it (better for judging):** follow the steps, give each prompt to the agent, and compare what it writes with the final code.
- **Short on time:** copy in the final code one file at a time, then ask the agent *"Explain this file line by line, simply"* until you can explain it yourself.

Either way, **commit after every step**.

---

## Step 1 · Connect to MongoDB (15 min)
**Prompt:**
> Read CLAUDE.md. Make db.js that connects with the mongodb driver to mongodb://127.0.0.1:27017, database
> Hack_MONGOse, and exports connect() and items() (the "items" collection). In server.js use express.json(), serve
> the public folder, mount routes/items.js and routes/extra.js at /api, and only listen on port 3000 after connect()
> finishes. Create routes/items.js and routes/extra.js as empty Express routers.

**Test:** `node server.js` → prints `Connected to MongoDB` and `Open http://127.0.0.1:3000/`.
**Commit + push now.** Person 2 needs `db.js`.
```bash
git add . && git commit -m "Connect to MongoDB and set up routes" && git push -u origin person1
```

## Step 2 · POST /api/items (20 min)
**Prompt:**
> In routes/items.js add POST /items. Trim all fields. type must be lost or found, and item, location, date, contact
> are required. date must be YYYY-MM-DD and not in the future. Send 400 { error } with a clear message when
> something is wrong. Otherwise insert the item with resolved:false and createdAt:new Date() and return 201 with the
> saved item.

**Test:**
```bash
curl -i -X POST http://127.0.0.1:3000/api/items -H "Content-Type: application/json" -d "{\"type\":\"lost\",\"item\":\"Black charger\",\"location\":\"Library\",\"date\":\"2026-10-25\",\"contact\":\"9876543210\"}"
# 201
curl -i -X POST http://127.0.0.1:3000/api/items -H "Content-Type: application/json" -d "{\"type\":\"stolen\"}"
# 400
```
(Windows PowerShell: use `curl.exe`, or use Postman.)
**Commit:** `git commit -am "Add POST /api/items with validation"`

## Step 3 · GET /api/items with search and filters (20 min)
**Prompt:**
> Add GET /items. Build a filter from the query string. type and location are exact matches. q is a
> case-insensitive $regex on item, with special characters escaped first. Unless showResolved is "true", add
> resolved:false. Sort by createdAt, newest first.

**Test in the browser:**
- `http://127.0.0.1:3000/api/items`
- `http://127.0.0.1:3000/api/items?type=lost`
- `http://127.0.0.1:3000/api/items?q=CHARGER` (finds "charger", because upper/lower case doesn't matter)
- `http://127.0.0.1:3000/api/items?q=((` (must not crash)

**Commit + push**, then tell Persons 3 and 4 the API is ready.

🟢 **Merge #1 at 1:20** (commands in `00-START-HERE.md`).

## Step 4 · README (at 2:20)
Put your team name and members into `README.md`, and check that the routes table is still correct.

---

## Questions judges may ask you
| Question | Answer |
| --- | --- |
| Why `listen` only after `connect()`? | So no request arrives before the database is ready. |
| What does `express.json()` do? | It turns the JSON body of a request into `req.body`. |
| What does `express.static("public")` do? | It sends the HTML, CSS and JS files in `public/` to the browser. |
| What does `$options: "i"` do? | The search ignores upper and lower case. |
| Why escape the search text? | Characters like `(` or `*` have special meaning in a regex. They would crash or change the search. |
| Why add `resolved: false` to the filter? | Resolved items are hidden by default. The checkbox sends `showResolved=true` to include them. |
| Why 201 and not 200? | 201 means "a new thing was created". |
| Why compare dates as text (`date > today`)? | `YYYY-MM-DD` text sorts in the same order as the dates do. |

---

## Full code

### `package.json`
```json
{
  "name": "lost-and-found",
  "version": "1.0.0",
  "description": "Campus Lost and Found Portal - hackathon project",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "seed": "node seed.js"
  },
  "dependencies": {
    "express": "^4.21.2",
    "mongodb": "^6.12.0"
  }
}
```

### `db.js`
```js
// db.js - connects to MongoDB once and shares the "items" collection
const { MongoClient } = require("mongodb");

const client = new MongoClient("mongodb://127.0.0.1:27017");
const DB_NAME = "Hack_MONGOse";

let db;

async function connect() {
  await client.connect();
  db = client.db(DB_NAME);
  console.log("Connected to MongoDB, database:", DB_NAME);
}

function items() {
  return db.collection("items");
}

module.exports = { connect, items, client, DB_NAME };
```

### `server.js`
```js
// server.js - starts the Express app
const express = require("express");
const { connect } = require("./db");

const app = express();

app.use(express.json()); // read JSON bodies into req.body
app.use(express.static("public")); // serve index.html, css and js files

app.use("/api", require("./routes/items")); // Person 1: GET + POST /api/items
app.use("/api", require("./routes/extra")); // Person 2: resolve + matches

// start listening only after the database is connected
connect()
  .then(() => {
    app.listen(3000, () => console.log("Open http://127.0.0.1:3000/"));
  })
  .catch((err) => {
    console.error("Could not connect to MongoDB:", err.message);
    process.exit(1);
  });
```

### `routes/items.js`
```js
// routes/items.js - add an item, list/search/filter items (Person 1)
const express = require("express");
const { items } = require("../db");

const router = express.Router();

// POST /api/items - add a lost or found item
router.post("/items", async (req, res) => {
  try {
    const body = req.body || {};
    const type = String(body.type || "").trim();
    const item = String(body.item || "").trim();
    const location = String(body.location || "").trim();
    const date = String(body.date || "").trim();
    const contact = String(body.contact || "").trim();

    if (type !== "lost" && type !== "found") {
      return res.status(400).json({ error: "type must be lost or found" });
    }
    if (!item || !location || !date || !contact) {
      return res.status(400).json({ error: "item, location, date and contact are required" });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ error: "date must be in YYYY-MM-DD format" });
    }
    const today = new Date().toISOString().slice(0, 10);
    if (date > today) {
      return res.status(400).json({ error: "date cannot be in the future" });
    }

    const newItem = { type, item, location, date, contact, resolved: false, createdAt: new Date() };
    const result = await items().insertOne(newItem);
    res.status(201).json({ _id: result.insertedId, ...newItem });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// GET /api/items?type=lost&location=Library&q=charger&showResolved=true
router.get("/items", async (req, res) => {
  try {
    const filter = {};
    if (req.query.type) filter.type = req.query.type;
    if (req.query.location) filter.location = req.query.location;
    if (req.query.q) {
      // escape special characters so text like "(" can't break the search
      const safe = req.query.q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.item = { $regex: safe, $options: "i" }; // "i" = ignore upper/lower case
    }
    if (req.query.showResolved !== "true") filter.resolved = false;

    const list = await items().find(filter).sort({ createdAt: -1 }).toArray();
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
```
