# Campus Lost & Found Portal

**Team:** MONGOse — Person 1 (server), Person 2 (resolve + matches), Person 3 (form + design), Person 4 (list + filters)
**Hackathon problem:** 11 · Lost and Found Portal

A website where students post things they **lost** or **found** on campus. Anyone can search posts and filter them by type and
location. When an item is returned, it can be marked **resolved**. Resolved items are hidden unless "Show resolved" is ticked.
The "Possible matches" button shows posts of the opposite type at the same location with a similar name.

> Team plan and step-by-step guides: start with [`docs/00-START-HERE.md`](docs/00-START-HERE.md).

## How to run
You need Node.js 18+ and MongoDB running on `mongodb://127.0.0.1:27017`.
```bash
npm install
node seed.js       # optional: adds 10 sample items
node server.js
```
Open **http://127.0.0.1:3000/**

## Data — collection `items` in database `Hack_MONGOse`
| Field | Notes |
| --- | --- |
| `type` | `lost` or `found` |
| `item` | what it is |
| `location` | Library, Canteen, Main Block, Lab Block, Hostel, Parking, Sports Ground, Other |
| `date` | `YYYY-MM-DD` |
| `contact` | phone or email |
| `resolved` | `false` when posted |
| `createdAt` | set by the server |

## API routes
| Method | Route | What it does | Status codes |
| --- | --- | --- | --- |
| GET | `/api/items?type=&location=&q=&showResolved=true` | List, search and filter items | 200 |
| POST | `/api/items` | Add an item | 201, 400 |
| PATCH | `/api/items/:id/resolve` | Mark an item resolved | 200, 400, 404, 409 |
| GET | `/api/items/:id/matches` | Possible matches for an item | 200, 400, 404 |

Errors are JSON: `{ "error": "message" }`.

## Files
```
server.js           starts Express, connects to MongoDB
db.js               MongoDB connection
routes/items.js     GET and POST /api/items
routes/extra.js     resolve and matches routes
seed.js             sample data
public/index.html   the page
public/style.css    styles
public/form.js      post form
public/list.js      item list, filters, buttons
public/matches.js   matches popup
```
