// routes/extra.js - mark resolved + possible matches (Person 2)
const express = require("express");
const { ObjectId } = require("mongodb");
const { items } = require("../db");

const router = express.Router();

// PATCH /api/items/:id/resolve - mark an item as resolved
router.patch("/items/:id/resolve", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid id" });
    }

    const item = await items().findOne({ _id: new ObjectId(id) });
    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }
    if (item.resolved) {
      return res.status(409).json({ error: "Item is already resolved" });
    }

    await items().updateOne({ _id: new ObjectId(id) }, { $set: { resolved: true } });
    item.resolved = true;
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// split a name into lowercase words with 3 or more letters
function words(text) {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 3);
}

// GET /api/items/:id/matches - opposite type, same location, a word in common
router.get("/items/:id/matches", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid id" });
    }

    const item = await items().findOne({ _id: new ObjectId(id) });
    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }

    const otherType = item.type === "lost" ? "found" : "lost";
    const candidates = await items()
      .find({ type: otherType, location: item.location, resolved: false })
      .toArray();

    const myWords = words(item.item);
    const matches = candidates.filter((c) => words(c.item).some((w) => myWords.includes(w)));
    res.json(matches);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
