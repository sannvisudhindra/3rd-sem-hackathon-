// routes/items.js - add an item, list/search/filter items (Person 1)
const express = require("express");
const { items } = require("../db");

const router = express.Router();

// POST /api/items - add a lost or found item
router.post("/items", async (req, res) => {
  try {
    const body = req.body || {};
    const type = String(body.type || "").trim();
    const item = String(body.item || "").trim();
    const location = String(body.location || "").trim();
    const date = String(body.date || "").trim();
    const contact = String(body.contact || "").trim();

    if (type !== "lost" && type !== "found") {
      return res.status(400).json({ error: "type must be lost or found" });
    }
    if (!item || !location || !date || !contact) {
      return res.status(400).json({ error: "item, location, date and contact are required" });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ error: "date must be in YYYY-MM-DD format" });
    }
    const today = new Date().toISOString().slice(0, 10);
    if (date > today) {
      return res.status(400).json({ error: "date cannot be in the future" });
    }

    const newItem = { type, item, location, date, contact, resolved: false, createdAt: new Date() };
    const result = await items().insertOne(newItem);
    res.status(201).json({ _id: result.insertedId, ...newItem });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// GET /api/items?type=lost&location=Library&q=charger&showResolved=true
router.get("/items", async (req, res) => {
  try {
    const filter = {};
    if (req.query.type) filter.type = req.query.type;
    if (req.query.location) filter.location = req.query.location;
    if (req.query.q) {
      // escape special characters so text like "(" can't break the search
      const safe = req.query.q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.item = { $regex: safe, $options: "i" }; // "i" = ignore upper/lower case
    }
    if (req.query.showResolved !== "true") filter.resolved = false;

    const list = await items().find(filter).sort({ createdAt: -1 }).toArray();
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
